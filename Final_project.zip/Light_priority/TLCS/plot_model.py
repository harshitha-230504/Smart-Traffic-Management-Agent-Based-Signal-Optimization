import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model
from tensorflow.keras import layers  # Corrected import for layers

def plot_model_with_matplotlib(model_path):
    model = load_model(model_path)
    layers_list = model.layers  # Renaming to avoid conflict with 'layers' import

    plt.figure(figsize=(10, 8))

    # Create a simple flowchart of layers (you can expand this logic as needed)
    for i, layer in enumerate(layers_list):
        # Check if the layer has an output_shape attribute
        output_shape = getattr(layer, 'output_shape', 'Unknown')
        
        # If it's an InputLayer, handle it separately
        if isinstance(layer, layers.InputLayer):
            output_shape = model.input_shape  # Get the model's input shape
        
        # Add text to represent each layer
        plt.text(0.5, 1 - (i / len(layers_list)), f"Layer {i + 1}: {layer.name} ({output_shape})", 
                 ha='center', fontsize=10)

    plt.axis('off')
    plt.show()

# Provide the path where your model is saved
model_path = 'models/model_2/trained_model.h5'
plot_model_with_matplotlib(model_path)
