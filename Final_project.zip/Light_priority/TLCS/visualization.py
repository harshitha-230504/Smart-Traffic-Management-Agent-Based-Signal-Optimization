import matplotlib.pyplot as plt
import os

class Visualization:
    def __init__(self, path, dpi):
        self._path = path
        self._dpi = dpi

    def save_data_and_plot(self, data, filename, xlabel, ylabel):
        """
        Produce a plot of performance of the agent over the session and save the relative data to txt
        """
        min_val = min(data)
        max_val = max(data)

        plt.rcParams.update({'font.size': 24})  # set bigger font size

        plt.plot(data)
        plt.ylabel(ylabel)
        plt.xlabel(xlabel)
        plt.margins(0)
        plt.ylim(min_val - 0.05 * abs(min_val), max_val + 0.05 * abs(max_val))
        fig = plt.gcf()
        fig.set_size_inches(20, 11.25)
        fig.savefig(os.path.join(self._path, 'plot_' + filename + '.png'), dpi=self._dpi)
        plt.close("all")

        with open(os.path.join(self._path, 'plot_' + filename + '_data.txt'), "w") as file:
            for value in data:
                file.write("%s\n" % value)

    def plot_performance_metrics(self, rewards, episode_lengths, action_counts, wait_times, throughput, loss_values, exploration_rates, success_count, total_episodes, state_counts):
        """
        Plot and save various performance metrics
        """

        # Average Reward
        avg_reward = sum(rewards) / len(rewards)
        self.save_data_and_plot(rewards, 'avg_reward', 'Episodes', 'Reward')
        
        # Cumulative Reward
        cumulative_reward = sum(rewards)
        print(f"Cumulative Reward: {cumulative_reward}")
        
        # Success Rate
        success_rate = success_count / total_episodes
        print(f"Success Rate: {success_rate * 100:.2f}%")

        # Average Episode Length
        avg_episode_length = sum(episode_lengths) / len(episode_lengths)
        print(f"Average Episode Length: {avg_episode_length}")

        # Action Distribution (Frequency of each action)
        self.save_data_and_plot(action_counts, 'action_distribution', 'Actions', 'Frequency')

        # Average Wait Time (for traffic signal control)
        avg_wait_time = sum(wait_times) / len(wait_times)
        print(f"Average Wait Time: {avg_wait_time:.2f} seconds")

        # Throughput (vehicles per time unit)
        avg_throughput = sum(throughput) / len(throughput)
        print(f"Average Throughput: {avg_throughput:.2f} vehicles per time unit")

        # Loss Curve (if applicable)
        self.save_data_and_plot(loss_values, 'loss_curve', 'Time Steps', 'Loss')

        # Exploration Rate (ratio of exploration vs exploitation)
        self.save_data_and_plot(exploration_rates, 'exploration_rate', 'Time Steps', 'Exploration Rate')

        # State Distribution
        self.save_data_and_plot(state_counts, 'state_distribution', 'States', 'Occurrences')

        # Plot all metrics in one figure
        plt.figure(figsize=(20, 10))
        plt.subplot(2, 3, 1)
        plt.plot(rewards)
        plt.title('Rewards')
        plt.xlabel('Episodes')
        plt.ylabel('Reward')

        plt.subplot(2, 3, 2)
        plt.plot(episode_lengths)
        plt.title('Episode Lengths')
        plt.xlabel('Episodes')
        plt.ylabel('Length')

        plt.subplot(2, 3, 3)
        plt.plot(action_counts)
        plt.title('Action Distribution')
        plt.xlabel('Actions')
        plt.ylabel('Frequency')

        plt.subplot(2, 3, 4)
        plt.plot(wait_times)
        plt.title('Wait Times')
        plt.xlabel('Time Steps')
        plt.ylabel('Wait Time')

        plt.subplot(2, 3, 5)
        plt.plot(throughput)
        plt.title('Throughput')
        plt.xlabel('Time Steps')
        plt.ylabel('Throughput')

        plt.subplot(2, 3, 6)
        plt.plot(loss_values)
        plt.title('Loss Curve')
        plt.xlabel('Time Steps')
        plt.ylabel('Loss')

        fig = plt.gcf()
        fig.set_size_inches(20, 15)
        fig.savefig(os.path.join(self._path, 'all_metrics.png'), dpi=self._dpi)
        plt.close("all")
