import traci
import numpy as np
import random
import timeit
import os
import matplotlib.pyplot as plt

PHASE_NS_GREEN = 0  # North-South Green
PHASE_NS_YELLOW = 1
PHASE_NSL_GREEN = 2  # North-South Left Turn Green
PHASE_NSL_YELLOW = 3
PHASE_EW_GREEN = 4  # East-West Green
PHASE_EW_YELLOW = 5
PHASE_EWL_GREEN = 6  # East-West Left Turn Green
PHASE_EWL_YELLOW = 7

class Simulation:
    def __init__(self, Model, TrafficGen, sumo_cmd, max_steps, green_duration, yellow_duration, num_states, num_actions):
        self._Model = Model
        self._TrafficGen = TrafficGen
        self._sumo_cmd = sumo_cmd
        self._max_steps = max_steps
        self._green_duration = green_duration
        self._yellow_duration = yellow_duration
        self._num_states = num_states
        self._num_actions = num_actions
        self._step = 0
        self._reward_episode = []
        self._queue_length_episode = []
        self._waiting_times = {}
        self._emergency_waiting_times = {}  # Track waiting times for emergency vehicles
        self._emergency_vehicle_count = []  # Track number of emergency vehicles per step

    def run(self, episode):
        start_time = timeit.default_timer()
        self._TrafficGen.generate_routefile(seed=episode)
        traci.start(self._sumo_cmd)
        print("Simulating...")

        self._step = 0
        old_total_wait = 0
        old_action = -1

        while self._step < self._max_steps:
            current_state = self._get_state()
            current_total_wait = self._collect_waiting_times()
            reward = old_total_wait - current_total_wait

            emergency_action = self._check_emergency_priority()
            action = emergency_action if emergency_action is not None else self._choose_action(current_state)

            if self._step != 0 and old_action != action:
                self._set_yellow_phase(old_action)
                self._simulate(self._yellow_duration)

            self._set_green_phase(action)
            self._simulate(self._green_duration)

            old_action = action
            old_total_wait = current_total_wait
            self._reward_episode.append(reward)

            # Track emergency vehicles and their waiting times
            self._track_emergency_vehicles()

        traci.close()
        simulation_time = round(timeit.default_timer() - start_time, 1)
        self._plot_results()  # Plot the results after the simulation
        return simulation_time

    def _simulate(self, steps_todo):
        if (self._step + steps_todo) >= self._max_steps:
            steps_todo = self._max_steps - self._step

        while steps_todo > 0:
            traci.simulationStep()
            self._step += 1
            steps_todo -= 1
            self._queue_length_episode.append(self._get_queue_length())

    def _collect_waiting_times(self):
        incoming_roads = ["E2TL", "N2TL", "W2TL", "S2TL"]
        car_list = traci.vehicle.getIDList()

        for car_id in car_list:
            wait_time = traci.vehicle.getAccumulatedWaitingTime(car_id)
            road_id = traci.vehicle.getRoadID(car_id)
            if road_id in incoming_roads:
                self._waiting_times[car_id] = wait_time
            elif car_id in self._waiting_times:
                del self._waiting_times[car_id]

        total_waiting_time = sum(self._waiting_times.values())
        return total_waiting_time

    def _choose_action(self, state):
        return np.argmax(self._Model.predict_one(state))

    def _set_yellow_phase(self, old_action):
        yellow_phase_code = old_action * 2 + 1
        traci.trafficlight.setPhase("TL", yellow_phase_code)

    def _set_green_phase(self, action_number):
        green_phases = [PHASE_NS_GREEN, PHASE_NSL_GREEN, PHASE_EW_GREEN, PHASE_EWL_GREEN]
        traci.trafficlight.setPhase("TL", green_phases[action_number])

    def _get_queue_length(self):
        halt_N = traci.edge.getLastStepHaltingNumber("N2TL")
        halt_S = traci.edge.getLastStepHaltingNumber("S2TL")
        halt_E = traci.edge.getLastStepHaltingNumber("E2TL")
        halt_W = traci.edge.getLastStepHaltingNumber("W2TL")
        return halt_N + halt_S + halt_E + halt_W

    def _get_state(self):
        state = np.zeros(self._num_states)
        car_list = traci.vehicle.getIDList()

        for car_id in car_list:
            lane_pos = traci.vehicle.getLanePosition(car_id)
            lane_id = traci.vehicle.getLaneID(car_id)
            lane_pos = 750 - lane_pos  # reverse position

            lane_cell = min(int(lane_pos / 7), 9)

            lane_group = -1
            if "W2TL" in lane_id:
                lane_group = 0 if lane_id.endswith(('0', '1', '2')) else 1
            elif "N2TL" in lane_id:
                lane_group = 2 if lane_id.endswith(('0', '1', '2')) else 3
            elif "E2TL" in lane_id:
                lane_group = 4 if lane_id.endswith(('0', '1', '2')) else 5
            elif "S2TL" in lane_id:
                lane_group = 6 if lane_id.endswith(('0', '1', '2')) else 7

            if lane_group != -1:
                car_position = int(f"{lane_group}{lane_cell}")
                state[car_position] = 1

        return state

    def _check_emergency_priority(self):
        emergency_vehicle_types = ["ambulance", "cm_vehicle"]

        for vehicle_id in traci.vehicle.getIDList():
            if traci.vehicle.getTypeID(vehicle_id) in emergency_vehicle_types:
                lane_id = traci.vehicle.getLaneID(vehicle_id)
                if "W2TL" in lane_id:
                    return 2 if lane_id.endswith(('0', '1', '2')) else 3
                elif "N2TL" in lane_id:
                    return 0 if lane_id.endswith(('0', '1', '2')) else 1
                elif "E2TL" in lane_id:
                    return 2 if lane_id.endswith(('0', '1', '2')) else 3
                elif "S2TL" in lane_id:
                    return 0 if lane_id.endswith(('0', '1', '2')) else 1

        return None

    def _track_emergency_vehicles(self):
        emergency_vehicle_types = ["ambulance", "cm_vehicle"]
        emergency_vehicle_count = 0

        for vehicle_id in traci.vehicle.getIDList():
            if traci.vehicle.getTypeID(vehicle_id) in emergency_vehicle_types:
                emergency_vehicle_count += 1
                wait_time = traci.vehicle.getAccumulatedWaitingTime(vehicle_id)
                self._emergency_waiting_times[vehicle_id] = wait_time

        self._emergency_vehicle_count.append(emergency_vehicle_count)

    def _plot_results(self):
        # Plotting reward and queue length
        self._show_plot(self._reward_episode, 'reward_episode', 'Action step', 'Reward')
        self._show_plot(self._queue_length_episode, 'queue_length_episode', 'Simulation Steps', 'Queue Length')

        # Plot emergency vehicle waiting times
        self._show_plot(list(self._emergency_waiting_times.values()), 'emergency_waiting_times', 'Vehicle ID', 'Waiting Time (s)')
        
        # Plot the count of emergency vehicles per step
        self._show_plot(self._emergency_vehicle_count, 'emergency_vehicle_count', 'Step', 'Emergency Vehicle Count')

    def _show_plot(self, data, filename, xlabel, ylabel):
        # Plot and display the figure
        plt.figure(figsize=(10, 6))
        plt.plot(data)
        plt.title(f"{ylabel} vs {xlabel}")
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.grid(True)
        plt.show()
