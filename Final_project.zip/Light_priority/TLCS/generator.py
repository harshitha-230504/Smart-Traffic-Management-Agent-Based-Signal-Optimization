import numpy as np
import math

class TrafficGenerator:
    def __init__(self, max_steps, n_cars_generated):
        self._n_cars_generated = n_cars_generated  # number of cars per episode
        self._max_steps = max_steps

    def generate_routefile(self, seed):
        """
        Generation of the route of every car for one episode
        """
        np.random.seed(seed)  # make tests reproducible

        # the generation of cars is distributed according to a weibull distribution
        timings = np.random.weibull(2, self._n_cars_generated)
        timings = np.sort(timings)

        # reshape the distribution to fit the interval 0:max_steps
        car_gen_steps = []
        min_old = math.floor(timings[1])
        max_old = math.ceil(timings[-1])
        min_new = 0
        max_new = self._max_steps
        for value in timings:
            car_gen_steps = np.append(car_gen_steps, ((max_new - min_new) / (max_old - min_old)) * (value - max_old) + max_new)

        car_gen_steps = np.rint(car_gen_steps)  # round every value to int -> effective steps when a car will be generated

        # produce the file for cars generation, one car per line
        with open("intersection/episode_routes.rou.xml", "w") as routes:
            print("""<routes>
            <vType accel="1.0" decel="4.5" id="standard_car" length="5.0" minGap="2.5" maxSpeed="25" sigma="0.5" color="yellow" />
            <vType accel="1.0" decel="4.5" id="ambulance" length="5.0" minGap="2.5" maxSpeed="25" sigma="0.5" color="red" />
            <vType accel="1.0" decel="4.5" id="cm_vehicle" length="5.0" minGap="2.5" maxSpeed="25" sigma="0.5" color="blue" />

            <route id="W_N" edges="W2TL TL2N"/>
            <route id="W_E" edges="W2TL TL2E"/>
            <route id="W_S" edges="W2TL TL2S"/>
            <route id="N_W" edges="N2TL TL2W"/>
            <route id="N_E" edges="N2TL TL2E"/>
            <route id="N_S" edges="N2TL TL2S"/>
            <route id="E_W" edges="E2TL TL2W"/>
            <route id="E_N" edges="E2TL TL2N"/>
            <route id="E_S" edges="E2TL TL2S"/>
            <route id="S_W" edges="S2TL TL2W"/>
            <route id="S_N" edges="S2TL TL2N"/>
            <route id="S_E" edges="S2TL TL2E"/>""", file=routes)

            # Define the probabilities for the vehicle types
            normal_prob = 0.90
            ambulance_prob = 0.05
            cm_vehicle_prob = 0.05

            # Ensure the sum of probabilities is 1
            assert normal_prob + ambulance_prob + cm_vehicle_prob == 1.0

            for car_counter, step in enumerate(car_gen_steps):
                straight_or_turn = np.random.uniform()
                # Assign vehicle priority based on probabilities
                vehicle_priority = np.random.choice([0, 1, 2], p=[normal_prob, ambulance_prob, cm_vehicle_prob])  # 85% normal, 10% ambulance, 5% CM vehicle
                vehicle_color = "yellow"  # default color for normal vehicles

                # Assign colors based on priority
                if vehicle_priority == 1:
                    vehicle_color = "red"  # ambulance
                    vehicle_type = "ambulance"
                elif vehicle_priority == 2:
                    vehicle_color = "blue"  # CM vehicle
                    vehicle_type = "cm_vehicle"
                else:
                    vehicle_color = "yellow"  # normal vehicle
                    vehicle_type = "standard_car"

                # Now, create routes for each vehicle, based on direction
                if straight_or_turn < 0.75:  # choose direction: straight or turn - 75% of times the car goes straight
                    route_straight = np.random.randint(1, 5)  # choose a random source & destination
                    if route_straight == 1:
                        print(f'    <vehicle id="W_E_{car_counter}" type="{vehicle_type}" route="W_E" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    elif route_straight == 2:
                        print(f'    <vehicle id="E_W_{car_counter}" type="{vehicle_type}" route="E_W" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    elif route_straight == 3:
                        print(f'    <vehicle id="N_S_{car_counter}" type="{vehicle_type}" route="N_S" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    else:
                        print(f'    <vehicle id="S_N_{car_counter}" type="{vehicle_type}" route="S_N" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                else:  # car that turn -25% of the time the car turns
                    route_turn = np.random.randint(1, 9)  # choose random source & destination
                    if route_turn == 1:
                        print(f'    <vehicle id="W_N_{car_counter}" type="{vehicle_type}" route="W_N" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    elif route_turn == 2:
                        print(f'    <vehicle id="W_S_{car_counter}" type="{vehicle_type}" route="W_S" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    elif route_turn == 3:
                        print(f'    <vehicle id="N_W_{car_counter}" type="{vehicle_type}" route="N_W" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    elif route_turn == 4:
                        print(f'    <vehicle id="N_E_{car_counter}" type="{vehicle_type}" route="N_E" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    elif route_turn == 5:
                        print(f'    <vehicle id="E_N_{car_counter}" type="{vehicle_type}" route="E_N" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    elif route_turn == 6:
                        print(f'    <vehicle id="E_S_{car_counter}" type="{vehicle_type}" route="E_S" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    elif route_turn == 7:
                        print(f'    <vehicle id="S_W_{car_counter}" type="{vehicle_type}" route="S_W" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)
                    elif route_turn == 8:
                        print(f'    <vehicle id="S_E_{car_counter}" type="{vehicle_type}" route="S_E" depart="{step}" departLane="random" departSpeed="10" color="{vehicle_color}" />', file=routes)

            print("</routes>", file=routes)

# Call the function to generate the route file with 1000 vehicles
traffic_gen = TrafficGenerator(max_steps=5400, n_cars_generated=1000)  # Example for 1000 cars
traffic_gen.generate_routefile(seed=42)
